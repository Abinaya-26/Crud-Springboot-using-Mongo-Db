package com.customer.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.customer.dto.CustomerDTO;
import com.customer.exception.CustomerException;
import com.customer.service.CustomerService;

@RestController
public class CustomerController {

	@Autowired
	private CustomerService customerService;
	
	
	@PostMapping("/customers")
	public ResponseEntity<CustomerDTO> addCustomer(@RequestBody CustomerDTO cust) {
		return new ResponseEntity<CustomerDTO>(customerService.addCustomer(cust),HttpStatus.CREATED);
		
	}
	
	@PutMapping("/customer/{id}")
	public void updateCustomer(@PathVariable long id,@RequestBody  CustomerDTO cust) throws CustomerException {
		cust.setId(id);
		customerService.updateCustomer(cust);
	}
	
	@GetMapping("/customers")
	public ResponseEntity<List<CustomerDTO>> getAllCustomers() {
		return new ResponseEntity<>(customerService.getAllCustomers(),HttpStatus.OK);
	}
	
	@GetMapping("customers/{customerid}")
	public ResponseEntity<CustomerDTO> getCustomerById(@PathVariable long customerId) throws CustomerException{
		return new ResponseEntity<CustomerDTO>(customerService.getCustomerById(customerId),HttpStatus.OK);
	}
	
	@DeleteMapping("/customers/{customerId}")
	void deleteProduct(long customerId) throws CustomerException{
		customerService.deleteProduct(customerId);
	}
}
