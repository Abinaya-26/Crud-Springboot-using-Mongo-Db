package com.customer.service;

import java.util.List;

import com.customer.dto.CustomerDTO;
import com.customer.entity.Customer;
import com.customer.exception.CustomerException;

public interface CustomerService {

	public CustomerDTO addCustomer(CustomerDTO cust);
	public void updateCustomer(CustomerDTO cust) throws CustomerException;
	List<CustomerDTO> getAllCustomers();
	CustomerDTO getCustomerById(long customerId) throws CustomerException ;
	void deleteProduct(long customerId) throws CustomerException;
}
