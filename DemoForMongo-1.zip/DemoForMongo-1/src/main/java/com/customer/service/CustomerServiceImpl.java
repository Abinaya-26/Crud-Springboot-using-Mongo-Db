package com.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.customer.dto.CustomerDTO;
import com.customer.entity.Customer;
import com.customer.exception.CustomerException;
import com.customer.repository.CustomerRepository;

@Service("custService")
@Transactional
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	private CustomerRepository repo;

	@Override
	public CustomerDTO addCustomer(CustomerDTO cust) {
		// TODO Auto-generated method stub
		Customer a = new Customer();
		a.setId(cust.getId());
		a.setName(cust.getName());
		a.setDescription(cust.getDescription());
		repo.save(a);
		
		
		return cust;
	}

	@Override
	public void updateCustomer(CustomerDTO cust) throws CustomerException {
		// TODO Auto-generated method stub
	  Optional<Customer> c= repo.findById(cust.getId());
	  
	  if(c.isPresent()) {
		  Customer name = new Customer();
		  name.setId(cust.getId());
		  name.setName(cust.getName());
		  name.setDescription(cust.getDescription());
		  repo.save(name);
	  }else {
		  throw new CustomerException("Not found id" + cust.getId());
	  }
	  
	 
	}

	@Override
	public List<CustomerDTO> getAllCustomers() {
		// TODO Auto-generated method stub
		List<Customer> c = repo.findAll();
		
		List<CustomerDTO> a = new ArrayList<>();
		
		for(Customer cust: c) {
			CustomerDTO customer = new CustomerDTO();
			customer.setId(cust.getId());
			customer.setName(cust.getName());
			customer.setDescription(cust.getDescription());
			a.add(customer);
		}
		
		return a;
	}

	@Override
	public CustomerDTO getCustomerById(long customerId) throws CustomerException {
		// TODO Auto-generated method stub
		 Optional<Customer> c= repo.findById(customerId);
		  Customer cust = c.get();
		  CustomerDTO name = new CustomerDTO();
		  if(c.isPresent()) {
			  
			  name.setId(cust.getId());
			  name.setName(cust.getName());
			  name.setDescription(cust.getDescription());
			 
		  }else {
			  throw new CustomerException("Not found id" + cust.getId());
		  }
		return name;
	}

	@Override
	public void deleteProduct(long customerId) throws CustomerException {
		// TODO Auto-generated method stub
		Optional<Customer> a = repo.findById(customerId);
		if(a.isPresent()) {
			repo.delete(a.get());
		}else {
			throw new CustomerException("Record Not found "+ customerId);
		}
		
	}

}
