package com.customer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoForMongo1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
